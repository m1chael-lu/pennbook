var express = require('express');
var session = require('express-session');
var routes = require('./routes/routes.js');
var app = express();

app.use(express.urlencoded());
// Setting up the Express Session
app.use(session({secret: 'loginSecret', username: null}));

// Defining the GET and POST requests
app.get('/', routes.get_main);
app.get('/signup', routes.get_signup);
app.post('/checkLogin', routes.post_checkLogin);
app.post('/createaccount', routes.post_createAccount);
app.post('/addrestaurant', routes.post_addRestaurant);
app.post('/deleterestaurant', routes.post_deleteRestaurant);
app.get('/restaurants', routes.post_restaurants);
app.get('/logout', routes.post_logout);
app.post('/retrieverestaurants', routes.post_retrieveRestaurants);

console.log('Author: lumich');
app.listen(8080);
console.log('Server running on port 8080. Now open http://localhost:8080/ in your browser!');
