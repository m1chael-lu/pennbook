var db = require('../models/database.js');

var getMain = function(req, res) {
	// Loading main page
	res.render('main.ejs', {message: null});
};

var getSignup = function(req, res) {
	// Loading signup page
	res.render('signup.ejs', {message: null});
};

var postCheckLogin = function(req, res) {
	// Pulling session, username, and request
	var session = req.session;
	var username = req.body.username;
	var password = req.body.password;
	
	db.login(username, password, function(err, data) {
		// Checking if login was successful
		if (data == null) {
			// If login failed, redirects back to main page with error message
			res.render('main.ejs', {message: "Error: Invalid Login"});
		} else if (data) {
			session.username = username;
			// If successfull, routes to the restaurant page
			res.redirect("/restaurants");
		}
	})
}

var createAccount = function(req, res) {
	// Pulling session, username, password, and fullname from req
	var session = req.session;
	var username = req.body.username;
	var password = req.body.password;
	var fullname = req.body.fullname;
	
	// Running the database function that verifies if a username is taken
	db.usernameCheck(username, function(err, data) {
		if (data == null) {
			// Creating account if the username is not taken
			db.createAccount(username, password, fullname, function(err) {
				res.render('signup.ejs', {message: err});
			});
			
			// Assigning session's username and redirecting'
			session.username = username;
			res.redirect("/restaurants");
		} else {
			
			// Signup fails
			res.render('signup.ejs', {message: "Invalid Login"});
		}
	})
}

var restaurantsList = function(req, res) {
	// Pulls session object
	var session = req.session;
	console.log("WRONG ROUTE");
	
	// Checks if logged in
	if (session.username == null) {
		res.render('main.ejs', {message: "Error: Not logged in"});
	}
	
	// If logged in, it pulls the lists of restaurants
	var inputName = session.username;
	db.getitems(function(err, data) {
				if (err) {
					console.log(err)
				} else {
					console.log(data);
					res.render('restaurants.ejs', {restaurants: data, user: inputName, message: null});
				}
			});
}

var addRestaurant = function(req, res) {
	// Pulls session and other inputs
	console.log("REACHED ADDRESTAURANT");
	var session = req.session;
	var latitude = req.body.latitude;
	var longitude = req.body.longitude;
	var name = req.body.name;
	var description = req.body.description;
	var creator = session.username;
	
	// Verifies that inputs are not empty
	if (longitude.length == 0 || latitude.length == 0 
		|| name.length == 0 || description.length == 0) {
			return res.send({
				success: false
			});
		}

	// Adds the restaurant with the input
	db.addrestaurant(longitude, latitude, name, description, creator, function(err) {
		console.log(err);
		if (err == null) {
			console.log("ADD SUCCESS");
			return res.send({
				success: true
			});
		}
	})
}

var deleteRestaurant = function(req, res) {
	var name = req.body.name;
	
	db.deleterestaurant(name, function(err) {
		console.log(err);
		if (err == null) {
			console.log("DELETE SUCCESS");
			return res.send({
				success: true
			})
		}
	})
}

var retrieveRestaurant = function(req, res) {
	db.getitems(function(err, data) {
				if (err) {
					console.log(err)
				} else {
					res.send(data);
				}
			});
}

var logOut = function(req, res) {
	// Pulls session and logs out
	var session = req.session;
	session.username = null;
	res.redirect("/");
}

// Defining the route functions
var routes = { 
  get_main: getMain,
  get_signup: getSignup,
  post_checkLogin: postCheckLogin,
  post_createAccount: createAccount,
  post_restaurants: restaurantsList,
  post_logout: logOut,
  post_addRestaurant: addRestaurant,
  post_deleteRestaurant: deleteRestaurant,
  post_retrieveRestaurants: retrieveRestaurant
};

module.exports = routes;
