var AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
var db = new AWS.DynamoDB();


var users_login = function(username, password, callback) {
	console.log('Logging in ' + username);
	
	// Defining parameters for lookup
	var params = {
      KeyConditionExpression: "username = :u",
      FilterExpression: "contains (password, :p)",
      ExpressionAttributeValues: {
		":u": {
			S: username
		},
		":p": {
			S: password
		}
	},
      TableName: "users"
  	};
	
	// Queries through the database of users to check if the username + password combination works
	db.query(params, function(err, data) {
		if (err || data.Items.length == 0) {
			callback(err, null);
		} else {
			callback(err, data.Items[0]);
		}
	})
};

var username_check = function(username, callback) {
  console.log('Looking up: ' + username); 
	
  // Defining parameters
  var params = {
      KeyConditions: {
        username: {
          ComparisonOperator: 'EQ',
          AttributeValueList: [ { S: username } ]
        }
      },
      TableName: "users",
  };
  
  // Querying the usernames to check if it exists
  db.query(params, function(err, data) {
    if (err || data.Items.length == 0) {
      callback(err, null);
    } else {
      callback(err, data);
    }
  });
}

var create_account = function(username, password, fullname, callback) {
  console.log('Adding: ' + username); 
  
  // Ensuring valid input
	if (password.length == 0) {
		callback("Invalid password");
	} else if (fullname.length == 0) {
		callback("Invalid Full Name");
	}
	if (fullname.split(" ").length != 2) {
		callback("Full Name must be two words");
	}
  
  // Defining the query parameters
  var params = {
      Item: {
	"username" : {
		S: username
	},
	"password" : {
		S: password
	},
	"fullname" : {
		S: fullname
	}
	},
	TableName: "users"

  };
  
    // Adding new account into users
	db.putItem(params, function(err, data) {
		if (err) callback(err);
		else console.log("successfully created account");
	});
}

var get_all_items = function(callback) {
	console.log("retrieving all items from restaurants");
	
	// Defining the table name
	var params = {
		TableName: "restaurants"
	};
	
	// Pulling all items from the restaurants table
	items = db.scan(params, function(err, data) {
		if (err) {
			callback(err, null);
		} else {
			callback(null, data.Items);
		}
	});
};

var add_restaurants = function(longitude, latitude, name, description, creator, callback) {
	//  Veryfing that the restaurant's inputs are not empty'
	if (longitude.length == 0 || latitude.length == 0 
		|| name.length == 0 || description.length == 0) {
			
		callback("Invalid Input");}
		
	// Defining parameters for item
	var params = {
      Item: {
	"name" : {
		S: name
	},
	"longitude" : {
		S: longitude
	},
	"latitude" : {
		S: latitude
	},
	"description" : {
		S: description
	},
	"creator" : {
		S: creator
	}
	},
	TableName: "restaurants"
  };
  
  // Inserting new restaurant
  db.putItem(params, function(err, data) {
		if (err) callback(err);
		else console.log("successfully added restaurant"); callback(null);
	});
}

var delete_restaurant = function(n, callback) {
	var params = {
		TableName: "restaurants",
		Key: {
			name: {
				S: n
			}
		}
	};
	db.deleteItem(params, function(err) {
		if (err) {
			console.log(err);
		} else {
			callback(null);
		}
	})
	
}
// Defining database functions
var database = { 
  login: users_login,
  usernameCheck: username_check,
  createAccount: create_account,
  getitems: get_all_items,
  addrestaurant: add_restaurants,
  deleterestaurant: delete_restaurant
};

module.exports = database;
                                        